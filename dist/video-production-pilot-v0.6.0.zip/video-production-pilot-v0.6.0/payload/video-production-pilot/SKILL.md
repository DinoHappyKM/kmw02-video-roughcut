---
name: video-production-pilot
description: 技能1「多機訪談與橫直式故事剪輯」。接續訪談、口播、宣導剪輯或審片；盤點本片與共用資產，依參考設計橫直版、開窗落點、IPE主次標及封面，保留多機、繁體字幕、人聲混音與XML交接驗收。MV歌曲敘事沿用技能2。
---

# 技能1：多機訪談與橫直式故事剪輯｜0.6.0

這是由儲存庫產生的自包含部署副本，流程與工作表均在 references。規則主檔仍於 GitHub 的 docs/production；更新後重新打包，不單獨維護本副本。

MV 歌曲與情境素材任務先走 [技能2：MV 情緒敘事剪輯](https://github.com/DinoHappyKM/kmw02-video-roughcut/blob/main/.agents/skills/mv-emotional-editing/SKILL.md) 及其專用流程；剪前確認、交付選擇與應用程式操作範圍優先適用。技能1雙機訪談流程保留。

輸入「0」或「主選單」時，先走 [影片主選單](https://github.com/DinoHappyKM/kmw02-video-roughcut/blob/main/.agents/skills/video-workflow-menu/SKILL.md)；這只顯示技能，不重設或修改現有工程。

## 先讀與確認

閱讀 [工作入口](references/START_HERE.md) 與 [狀態](references/docs/production/STATUS.md)。接續剪輯時依 [製作流程](references/docs/production/WORKFLOW.md) 讀目前工程與目標時間線；不能以舊輸出代替目前人工修改。ChatCut 連線以實際 get_active_project／read_project 驗證；連線未成功則處理 [連接與交接](references/docs/production/SETUP_AND_HANDOFF.md)，不假稱已接手。

## 依本次任務工作

- 新素材或新版本：盤點素材與內容地圖，沿用已確認方向，為每部作品建立需求卡；同場多機保留完整同步母版，成片使用獨立時間線。套用 [影片類型規則](references/docs/production/SCENARIOS.md)；普通疊軌不宣稱原生 Multicam。
- 字幕、補充畫面、封面、聲音或審片修改：先讀 [包裝與修改規則](references/docs/production/PACKAGING_RULES.md)，再限定本次修改範圍。該文件記錄本專案已確認的預設；作品另有明確指示時更新需求卡。
- XML／DaVinci 交接：主動讀 [素材自檢與必要轉檔](references/docs/production/XML_HANDOFF_RULES.md)，分辨媒體讀取、來源引用及功能轉移；在授權範圍檢查素材、建立必要副本、更新實際時間線引用、匯出後核對 XML，再完成目標軟體驗收。字幕、效果和聲音另訂交接方案，不能靠轉檔宣稱全部可編輯。
- 只整理測試回饋：不改時間線或素材。參考 [首輪回饋](references/docs/production/pilots/PILOT_001_LESSONS.md)，將新回饋轉成適用規則、證據狀態及 [回歸案例](references/docs/production/TEST_CASES.md)，同步相關工作表；不因一次缺口直接開發新引擎。

## 驗收與記錄

主動執行 [包裝規則的交付前自我檢查](references/docs/production/PACKAGING_RULES.md)：字幕單行置中、人聲降噪與副作用、繁中字形及適合影片的字型都是必檢項目；不通過先在已授權範圍修正並重驗，記錄證據或明確待審原因，不等使用者再次提醒。

逐份核對使用者指定及本次交付的時間線版本，記錄已修正、原本符合或未處理；字幕需讀完全部頁面並核對有效文字框，不能以新版通過代替另一份包裝稿。參考包裝規則的逐版本核對。

有 XML 需求時，以上自我檢查還要涵蓋媒體規格與來源對照、全部片段是否實際使用新副本、匯出檔引用與目標軟體播放。可驗證的先做；需要人工播放的項目附具體測試位置，不冒充已通過。

用 [交付檢查表](references/docs/production/templates/04_DELIVERY_CHECKLIST.md) 核對實際輸出與既有人工修改。明確區分設定核對、畫面抽查、完整播放、使用者驗收及學生重現；未執行保留待測。保持原始媒體、來源追蹤與其他作品完整。私人素材、逐字稿、人物資訊及工具暫時 ID 保存在本機，不寫入通用技能。

本技能不提供隱含的 GitHub 發布、安裝或時間線修改授權，執行範圍依目前使用者請求決定。

## 聲畫與情緒剪輯｜0.2.0

完整剪輯、重剪、MV與剪法診斷，先讀[情緒表達剪輯](references/docs/production/EMOTION_EDITING.md)做表達需求檢查，依聲畫證據、素材品質與可用工具選鏡、調度B-roll／字卡／聲音並記錄執行結果。只修字幕或整理回饋限定本次範圍。新MV方案、人工修改及交付仍遵循上方原流程。

## 橫直式視覺與資產｜0.6.0

新作品、包裝、字卡或封面先讀 [視覺與資產工作流](references/docs/production/VISUAL_WORKFLOW.md)，再依本片需要讀其 IPE 字形規範與圖片。主內容穩定後，先定主標／小次標文字及版位與安全區，再規劃寓意分鏡、合成代表樣張並批量繪圖。使用者授權先看完整字幕審片時直接交可修改草稿；未知詞保留待核對。直式上方 A／B-roll 同窗切換、中間標題、下方故事示意圖；本片公仔／畫風優先、共用庫 fallback，風格缺件才問。原 30:60 留作橫式 preset，不覆蓋當次參考。

保留完整字幕審校、原始素材與人工修改、同步及聲音／交接驗收。舊固定座標與調色只在相應 preset 使用，幀數依實際 fps 解讀，混音以實際聽感驗證。封面 9:16 背景中央 4:5 每邊內縮 15%。Motion／Suno 為後續接入方向，未提供自動接口；能力不足如實記錄並用可用素材準備製作。
